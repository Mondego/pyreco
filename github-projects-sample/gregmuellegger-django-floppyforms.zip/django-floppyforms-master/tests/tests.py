# flake8: noqa
from .test_deprecations import *
from .test_forms import *
from .test_gis import GisTests
from .test_modelforms import *
from .test_layouts import *
from .test_rendering import *
from .test_templatetags import *
from .test_widgets import *
from .test_fields import *
