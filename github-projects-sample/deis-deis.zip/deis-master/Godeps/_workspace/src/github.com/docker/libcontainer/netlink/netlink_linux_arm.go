package netlink

func ifrDataByte(b byte) uint8 {
	return uint8(b)
}
