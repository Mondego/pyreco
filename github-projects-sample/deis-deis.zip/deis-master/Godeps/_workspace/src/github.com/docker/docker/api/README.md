This directory contains code pertaining to the Docker API:

 - Used by the docker client when communicating with the docker daemon

 - Used by third party tools wishing to interface with the docker daemon
