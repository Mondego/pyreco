export GOPATH=$GOPATH:`pwd`
export PATH=$PATH:`pwd`/bin
