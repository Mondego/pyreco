package sql

import (
	"testing"
)

func TestSqlDatasource(t *testing.T) {
	// Canary

	// TODO: Need to find a testing database layer to test building a
	// statement cache.
}
