package etcd

const (
	version        = "v2"
	packageVersion = "v2.0.0+git"
)
