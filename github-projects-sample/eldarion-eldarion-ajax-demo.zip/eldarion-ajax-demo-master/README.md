eldarion-ajax demo
===================

This is a quick and simple demo project to show how many of the features of eldarion-ajax (http://github.com/eldarion/eldarion-ajax) work.

You can find this online at a Gondor (https://gondor.io) instance here:

http://uk013.gondor.co/
