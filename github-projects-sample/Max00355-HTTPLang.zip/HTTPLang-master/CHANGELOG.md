Change Log
==========

v0.1.0
* Introduced loops
* First official version
