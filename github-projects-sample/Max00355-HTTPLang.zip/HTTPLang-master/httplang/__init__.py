from . import httplang
import sys

def console_main():
	httplang.main()
