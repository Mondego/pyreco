from turtle import *

speed(11)
shape("turtle")

ilosc_scian = 12
kat = 360 / ilosc_scian 

for licznik in range(ilosc_scian):
    forward(100)
    left(kat)
