The contents of this repository are licensed as follows:

This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/.

The contents of this repository are used to generate the Code Club projects seen on websites such as codeclubprojects.org and projects.codeclubworld.org. The terms of use related to Code Club projects is covered by our terms and conditions: https://www.codeclub.org.uk/terms-and-conditions
