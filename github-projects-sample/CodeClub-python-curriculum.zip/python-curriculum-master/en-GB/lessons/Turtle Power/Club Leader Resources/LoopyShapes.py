from turtle import *

speed(11)
shape("turtle")

for count in range(6):
	forward(100)
	right(60)

done()
