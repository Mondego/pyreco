print("Add any resources that children may need into this folder.")

