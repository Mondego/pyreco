print("Parabéns" + "!"*10 )

print("")
print("Aqui vai um dinossauro!")
print("")

print(" "*13 + "__")
print(" "*12 + "/ _)")
print(" "*5 + ".-^^^-/" + " /")
print("  __/" + " "*7 + "/")
print(" <__.|_|-|_|")

print("")
print("E aqui vai um bolo! hummmmmmmm")
print("")

print(" ."*10)
print(" i"*10)
print("#"*21)
print("="*21)
print("#"*21)
print("="*21)
print("#"*21)
