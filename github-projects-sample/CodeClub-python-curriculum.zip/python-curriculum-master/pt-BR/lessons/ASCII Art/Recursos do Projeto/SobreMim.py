print("Meu animal favorito é a ovelha:")
print('''
  o-###-
    | |   #
''')
print("Eu moro em São Paulo:")
print('''
   _|_
  |   |
  |#  |____
  |   |    |
  |  #|  # |
  |   | #  |
''')
