ENV = 'prod'

# Cache in-memory: http://pythonhosted.org/Flask-Cache/
CACHE_TYPE = 'simple'

LOG_PATH = '/home/vim/logs/flask/flask.log'
