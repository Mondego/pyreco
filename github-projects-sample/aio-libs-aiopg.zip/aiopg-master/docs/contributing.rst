.. _aiopg-contributing:

.. include:: ../CONTRIBUTING.rst
