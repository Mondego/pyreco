from django.contrib import admin
from .models import FakeMenuItemExtension

admin.site.register(FakeMenuItemExtension)
