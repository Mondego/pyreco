﻿To run the tests:
  python run-tests.py

To calculate code coverage:
  python run-coverage.py