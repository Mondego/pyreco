David3 reported that Py2exe has some problems with getting certain .ico formats to work as the icon for the .exe file. To get it to work you need the order of the images in the icon to be from the largest to the smallest (48, 32, 16).

I used XnViewMP (create multi-page file), let's see if this works.
