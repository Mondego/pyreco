class BackendError(Exception):
    """Backend related errors."""

class DeviceError(Exception):
    """Device related errors."""
