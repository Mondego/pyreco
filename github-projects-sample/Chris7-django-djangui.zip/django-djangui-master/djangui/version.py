from django import get_version
from distutils.version import StrictVersion
DJANGO_VERSION = StrictVersion(get_version())
DJ18 = StrictVersion('1.8')
DJ17 = StrictVersion('1.7')
DJ16 = StrictVersion('1.6')