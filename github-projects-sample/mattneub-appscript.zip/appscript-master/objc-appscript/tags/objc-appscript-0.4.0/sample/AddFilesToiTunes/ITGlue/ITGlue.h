
/*
 * ITGlue.h
 *
 * /Applications/iTunes.app
 * osaglue 0.3.2
 *
 */

#import "Appscript/Appscript.h"
#import "ITApplicationGlue.h"
#import "ITCommandGlue.h"
#import "ITConstantGlue.h"
#import "ITReferenceGlue.h"
#import "ITReferenceRendererGlue.h"

