/*
 * ASDefaultConstantGlue.h
 *
 * <default terminology>
 * osaglue 0.3.2
 *
 */

#import <Foundation/Foundation.h>


#import "Appscript/Appscript.h"


@interface ASDefaultConstant : ASConstant
+ (id)constantWithCode:(OSType)code_;
@end


