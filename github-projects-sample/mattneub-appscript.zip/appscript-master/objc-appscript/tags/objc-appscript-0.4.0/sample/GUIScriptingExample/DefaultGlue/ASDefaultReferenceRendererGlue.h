/*
 * ASDefaultReferenceRendererGlue.h
 *
 * <default terminology>
 * osaglue 0.3.2
 *
 */

#import <Foundation/Foundation.h>


#import "Appscript/Appscript.h"


@interface ASDefaultReferenceRenderer : ASReferenceRenderer
@end
