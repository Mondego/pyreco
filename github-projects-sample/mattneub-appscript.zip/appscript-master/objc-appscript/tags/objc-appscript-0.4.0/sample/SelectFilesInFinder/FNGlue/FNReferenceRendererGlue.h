/*
 * FNReferenceRendererGlue.h
 *
 * /System/Library/CoreServices/Finder.app
 * osaglue 0.3.1
 *
 */

#import <Foundation/Foundation.h>


#import "Appscript/Appscript.h"


@interface FNReferenceRenderer : ASReferenceRenderer
@end
