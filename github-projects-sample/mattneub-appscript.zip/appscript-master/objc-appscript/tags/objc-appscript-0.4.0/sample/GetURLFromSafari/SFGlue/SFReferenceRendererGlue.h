/*
 * SFReferenceRendererGlue.h
 *
 * /Applications/Safari.app
 * osaglue 0.3.2
 *
 */

#import <Foundation/Foundation.h>


#import "Appscript/Appscript.h"


@interface SFReferenceRenderer : ASReferenceRenderer
@end
