//
//  AEMReferenceTest.h
//  Appscript
//
//   Copyright (C) 2007-2008 HAS
//

#import <SenTestingKit/SenTestingKit.h>
#import "Appscript.h"

@interface AEMReferenceTest : SenTestCase {

}

@end
