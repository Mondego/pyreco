
#import <Foundation/Foundation.h>
#import "Appscript/Appscript.h"

void aemExample(void);