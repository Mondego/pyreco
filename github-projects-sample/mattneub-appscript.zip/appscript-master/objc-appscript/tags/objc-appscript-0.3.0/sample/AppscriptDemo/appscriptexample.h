
#import <Foundation/Foundation.h>
#import "TEGlue/TEGlue.h"

void appscriptExample(void);