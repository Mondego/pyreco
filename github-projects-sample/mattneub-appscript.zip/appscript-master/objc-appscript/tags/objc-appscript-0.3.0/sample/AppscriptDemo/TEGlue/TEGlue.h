
/*
 * TEGlue.h
 *
 * /Applications/TextEdit.app
 * osaglue 0.3.0
 *
 */

#import "Appscript/Appscript.h"
#import "TEApplicationGlue.h"
#import "TECommandGlue.h"
#import "TEConstantGlue.h"
#import "TEReferenceGlue.h"
#import "TEReferenceRendererGlue.h"

