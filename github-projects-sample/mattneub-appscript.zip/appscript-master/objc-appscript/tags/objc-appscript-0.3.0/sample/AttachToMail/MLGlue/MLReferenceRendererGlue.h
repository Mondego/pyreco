/*
 * MLReferenceRendererGlue.h
 *
 * /Applications/Mail.app
 * osaglue 0.3.0
 *
 */

#import <Foundation/Foundation.h>


#import "Appscript/Appscript.h"


@interface MLReferenceRenderer : ASReferenceRenderer
@end
