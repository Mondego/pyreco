/*
 * ITGlue.h
 * /Applications/iTunes.app
 * osaglue 0.5.1
 *
 */

#import <Foundation/Foundation.h>
#import "Appscript/Appscript.h"
#import "ITApplicationGlue.h"
#import "ITCommandGlue.h"
#import "ITConstantGlue.h"
#import "ITReferenceGlue.h"
#import "ITReferenceRendererGlue.h"
