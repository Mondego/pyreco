ASTranslate project source

Requirements:

- appscript 0.16.1 <http://appscript.sourceforge.net>

- pyobjc <http://pyobjc.sourceforge.net>

- py2app <http://undefined.org/python/>

--

To build, cd to ASTranslate-source-0.2.0 directory and run:

	python setup.py py2app
