""" constants """

kLanguageCount = 3

# (note: these are same as indexes of segmented control in window)
kLangPython = 0
kLangRuby = 1
kLangObjC = 2

kLangAll = None


class kNoParam: pass
