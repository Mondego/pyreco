#!/usr//bin/ruby

require 'appscript'
include Appscript

app('Finder').help('-t -i')

