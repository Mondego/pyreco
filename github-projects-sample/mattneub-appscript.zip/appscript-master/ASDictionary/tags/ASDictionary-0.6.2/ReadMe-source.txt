ASDictionary project source

Requirements:

- appscript 0.16.2 <http://appscript.sourceforge.net>

- py2app <http://undefined.org/python/>

--

To build, cd to ASDictionary-source-0.6.2 directory and run:

	python setup.py py2app
