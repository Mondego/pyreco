Summary

    - Machine learning toolkit for natural language processing.
    - Originally written for Lisbon Machine Learning Summer School (lxmls.it.pt)

Installation
    - Please read instructions in the Day 0 chapter of the LXMLS guide.
