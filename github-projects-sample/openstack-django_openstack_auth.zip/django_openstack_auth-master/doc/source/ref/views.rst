================
The Views Module
================

.. automodule:: openstack_auth.views
   :members:
