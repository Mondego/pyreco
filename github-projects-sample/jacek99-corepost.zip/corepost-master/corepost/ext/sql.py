'''
Created on 2012-04-17

@author: jacekf
'''

class SqlEntityService:
    pass
