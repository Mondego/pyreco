Twisted REST micro-framework
================================

Inspired by the *Flask* API.
Provides a more Flask/Sinatra-style API on top of the core *twisted.web* APIs.

See our HTML documentation:
http://jacek99.github.com/corepost/

or the PDF version:
https://github.com/jacek99/corepost/raw/gh-pages/doc/build/latex/CorePost.pdf

END OF LIFE NOTICE
==================

This project is not maintained any more, as I do not work with Python these days.

If anyone is interested in forking it and taking it over, feel free to contact me.
