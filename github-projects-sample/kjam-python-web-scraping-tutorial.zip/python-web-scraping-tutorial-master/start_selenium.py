from selenium import webdriver

browser = webdriver.Firefox()
