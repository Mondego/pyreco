if (!jQuery) {
    jQuery = django.jQuery;
}
