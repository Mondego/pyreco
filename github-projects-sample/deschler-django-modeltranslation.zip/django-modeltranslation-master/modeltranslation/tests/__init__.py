# For Django < 1.6 testrunner
from .tests import *  # NOQA
