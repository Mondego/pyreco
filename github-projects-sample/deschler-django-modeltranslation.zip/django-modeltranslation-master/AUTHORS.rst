Authors
=======

Core Committers
---------------

* Peter Eschler <peschler@gmail.com> (retired)
* Dirk Eschler <eschler@gmail.com>
* Jacek Tomaszewski <jacek.tomek@gmail.com>

Contributors
------------

* Carl J. Meyer
* Jaap Roes
* Bojan Mihelac
* Sébastien Fievet
* Bruno Tavares
* Zach Mathew (of django-linguo_, initial author of ``MultilingualManager``)
* Mihai Sucan
* Benoît Bryon
* Wojtek Ruszczewski
* Chris Adams
* Dominique Lederer
* Braden MacDonald
* Karol Fuksiewicz
* Konrad Wojas
* Bas Peschier
* Oleg Prans
* Francesc Arpí Roca
* Mathieu Leplatre
* Thom Wiggers
* Warnar Boekkooi
* Alex Marandon
* Fabio Caccamo
* Vladimir Sinitsin
* Luca Corti
* Morgan Aubert
* Mathias Ettinger
* Daniel Loeb
* Stephen McDonald
* Lukas Lundgren
* zenoamaro
* oliphunt
* Venelin Stoykov
* Stratos Moros
* And many more ... (if you miss your name here, please let us know!)

.. _django-linguo: https://github.com/zmathew/django-linguo
