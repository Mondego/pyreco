Flask-WeasyPrint
================

Make PDF with WeasyPrint_ in your Flask_ app.

* BSD licensed
* Python 2.6, 2.7 and 3.3
* Latest documentation `on python.org`_
* Source, issues and pull requests `on Github`_
* Releases `on PyPI`_

.. _Flask: http://flask.pocoo.org/
.. _WeasyPrint: http://weasyprint.org/
.. _on python.org: http://packages.python.org/Flask-WeasyPrint/
.. _on Github: https://github.com/SimonSapin/Flask-WeasyPrint/
.. _on PyPI: http://pypi.python.org/pypi/Flask-WeasyPrint
