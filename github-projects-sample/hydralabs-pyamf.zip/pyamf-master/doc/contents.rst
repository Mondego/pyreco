%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 PyAMF Documentation contents
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

.. toctree::

   whatsnew/index.rst
   tutorials/index.rst
   architecture/index.rst
   community/index.rst

   install.rst
   about.rst
   bugs.rst
   license.rst
   changelog.rst
