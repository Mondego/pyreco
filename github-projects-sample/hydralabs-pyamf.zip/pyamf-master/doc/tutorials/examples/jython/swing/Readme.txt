Swing
=====

This folder contains the Jython Swing example for PyAMF. 

More info can be found in the documentation:
http://pyamf.org/tutorials/jython/swing.html
