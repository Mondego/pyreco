====================
Python Shell Example
====================

This example shows how to control a remote Python interpreter
from a Flex client.

More info can be found in the documentation:
http://pyamf.org/tutorials/actionscript/shell.html