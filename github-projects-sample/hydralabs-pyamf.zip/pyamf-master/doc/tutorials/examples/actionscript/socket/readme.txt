=============
Socket server
=============

This examples shows how to use Socket class in
ActionScript 3, that allows you to make socket
connections and to read and write raw binary data.

To run the example, you need to start the server
(in python/server.py) and running on the same domain
where the SWF resides (in the example, localhost) 
and listening on port 8000.

More info can be found in the documentation:
http://pyamf.org/tutorials/actionscript/socket.html