# Copyright (c) The PyAMF Project.
# See LICENSE.txt for details.

from django.db import models

# Create your models here.
