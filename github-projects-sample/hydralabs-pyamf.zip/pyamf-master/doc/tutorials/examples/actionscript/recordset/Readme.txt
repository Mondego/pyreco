RecordSet Example
=================

This folder contains the Flash and Python files
for the `RecordSet` example. 

More info can be found in the documentation:
http://pyamf.org/tutorials/actionscript/recordset.html
