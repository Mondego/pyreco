Authentication
==============

This folder contains the authentication examples
for PyAMF.

More info can be found in the documentation:
http://pyamf.org/tutorials/general/authentication.html
