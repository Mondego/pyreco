Google App Engine
=================

This is a Google App Engine example. More info can be found in the documentation:
http://pyamf.org/tutorials/gateways/appengine.html
