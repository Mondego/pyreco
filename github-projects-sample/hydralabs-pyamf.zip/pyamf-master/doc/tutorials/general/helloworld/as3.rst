****************************
  Adobe Flash CS3 or newer
****************************

.. topic:: Introduction

   This |ActionScript (TM)| 3.0 example can be used with
   the Adobe Flash CS3 (or newer) authoring tool. 

.. contents::

Source
======

- `helloworld.fla <../../examples/general/helloworld/flash/as3/src/helloworld.fla>`_
- `helloworld.as <../../examples/general/helloworld/flash/as3/src/HelloWorld.as>`_
- `helloworld.swf <../../examples/general/helloworld/flash/as3/deploy/assets/helloworld.swf>`_


.. |ActionScript (TM)| unicode:: ActionScript U+2122
