****************************
  Adobe Flash CS3 or newer
****************************

.. topic:: Introduction

   This |ActionScript (TM)| 3.0 example can be used with
   the Adobe Flash CS3 (or newer) authoring tool. 

.. contents::

Source
======

- `authentication.fla <../../examples/general/authentication/flash/as3/authentication.fla>`_
- `Authentication.as <../../examples/general/authentication/flash/as3/Authentication.as>`_
- `authentication.swf <../../examples/general/authentication/flash/as3/authentication.swf>`_


.. |ActionScript (TM)| unicode:: ActionScript U+2122