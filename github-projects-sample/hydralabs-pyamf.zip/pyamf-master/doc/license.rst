.. include:: <isonum.txt>
.. highlightlang:: none

.. _license:

********
License
********

.. include:: ../LICENSE.txt