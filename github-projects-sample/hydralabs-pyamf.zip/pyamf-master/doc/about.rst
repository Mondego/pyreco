=====================
About these documents
=====================

These documents are generated from `reStructuredText
<http://docutils.sourceforge.net/rst.html>`_ sources by `Sphinx
<http://sphinx.pocoo.org>`_, a document processor
specifically written for the official Python documentation.

In the online version of these documents, you can submit comments and
suggest changes directly on the documentation pages.

Development of the documentation takes place on the
:doc:`users mailing list <community/mailinglist>`. We're
always looking for volunteers wanting to help with the docs, so feel
free to send a mail there!

See :ref:`reporting-bugs` for information how to report bugs in PyAMF.
