*************
 Community
*************

.. toctree::
   :maxdepth: 1

   download.rst
   mailinglist.rst
   irc.rst
   team.rst
   thanks.rst
   maintainers.rst