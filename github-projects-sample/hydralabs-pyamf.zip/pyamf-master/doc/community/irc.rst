================
  IRC Channel
================

We created an `IRC <http://en.wikipedia.org/wiki/IRC>`_ channel
on the dhIRC network for informal PyAMF discussions, asking
questions or just hanging out and "socializing".

The channel is `#pyamf on irc.freenode.net <irc://irc.freenode.net/pyamf>`_.

If you do not have an IRC client, you can join using the
`Web Chat Client <http://webchat.freenode.net/>`_.

Drop by if you are interested in the development of PyAMF, have
a quick question or just want to get to know the people
developing and using it. If you're new to IRC, be sure to
learn how to
`get answers <http://www.mikeash.com/getting_answers.html>`_.

