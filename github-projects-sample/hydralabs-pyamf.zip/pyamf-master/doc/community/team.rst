========
  Team
========

The developers with commit access are listed in the
:doc:`maintainers` document.

See the :doc:`thanks` document for the list of contributors.

And thanks to everyone who keeps providing us with great
feedback, helping to improve PyAMF.