Contributors to PyAMF
---------------------

This section lists people who have contributed in some way to PyAMF.
It is probably not complete -- if you feel that you or anyone else
should be on this list, please let us know (send email to the
:doc:`users mailinglist <mailinglist>`), and we'll be glad to correct
the problem.

- Evert Pot
- Bob Ippolito
- Joachim Bauch
- Antti Kaihola
- Jacob Feisley
- Gerard Escalante

Thanks to Dave Thompson from the Arizona Research Laboratories (University of
Arizona) for contributing (amongst other things) an adapter for SQLAlchemy.

And everyone who keeps sending feedback, helping us improve PyAMF.
