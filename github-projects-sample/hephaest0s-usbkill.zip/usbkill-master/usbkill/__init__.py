from usbkill import go
