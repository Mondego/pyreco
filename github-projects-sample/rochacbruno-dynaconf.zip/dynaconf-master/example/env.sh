#!/usr/bin/env bash
export EXAMPLE_SETTINGS_MODULE=mysettings
export EXAMPLE_MYSQL_PASSWD=SuperSecret