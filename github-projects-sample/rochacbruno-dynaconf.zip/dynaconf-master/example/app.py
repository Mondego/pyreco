# coding: utf-8

from .conf import settings

print settings.MYSQL_HOST
print settings.MYSQL_PASSWD
print settings.EXAMPLE