# coding: utf-8
from dynaconf.loaders.redis_loader import write, delete  # noqa
