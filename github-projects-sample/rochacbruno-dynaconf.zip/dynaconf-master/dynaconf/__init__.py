# coding: utf-8
from dynaconf.base import LazySettings
settings = LazySettings()

__all__ = ['settings']
