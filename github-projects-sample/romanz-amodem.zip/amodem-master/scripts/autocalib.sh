#!/bin/bash
amodem-cli send -vv -c auto | amodem-cli recv -vv -c auto
