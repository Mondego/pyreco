float xmlPage(char* input_tif, char* output_xml);
