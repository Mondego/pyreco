#ifndef __cygwin_nt-6.1__
	#define __cygwin_nt-6.1__
#endif
