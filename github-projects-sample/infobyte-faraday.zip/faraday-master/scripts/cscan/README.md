# cscan
Faraday Continuous Scanning

More information:
[http://blog.infobytesec.com/2015/09/faraday-continuous-scanning.html] (http://blog.infobytesec.com/2015/09/faraday-continuous-scanning.html)
