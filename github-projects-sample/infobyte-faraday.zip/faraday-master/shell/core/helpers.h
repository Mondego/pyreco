#ifndef	_HELPERS_H_
#define	_HELPERS_H_

int wcwidth(unsigned short ucs);

#endif
