#!/usr/bin/env python
'''
Faraday Penetration Test IDE
Copyright (C) 2013  Infobyte LLC (http://www.infobytesec.com/)
See the file 'doc/LICENSE' for the license information

'''

class View(object):
    """A view for the data in a CouchDB"""
    def __init__(self):
        pass
        

class HostsServiceFrequencies(View):
    pass
