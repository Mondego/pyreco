// Faraday Penetration Test IDE
// Copyright (C) 2013  Infobyte LLC (http://www.infobytesec.com/)
// See the file 'doc/LICENSE' for the license information

reports = ["compound", "byservices", "summarized", "vulns", "commands"];
designs = {"balls": "hosts", "treemap": "hosts", "byservices": "hosts", "summarized": "hosts", "vulns": "hosts", "compound": "hosts", "commands": 'commands'};
views = {"balls": "byservices", "treemap": "byservices", "tuvieja": "summarized", "byservices": "byservices", "summarized": "summarized", "vulns": "vulns", "compound": "compound", "commands":"list"};
sizes = {"byservices": "450", "summarized": "250", "vulns" : "200", "compound": ""}    

