#Acknowledgements

### From the files I started with:
https://gist.github.com/abishur/2482046
"Topmenu and the submenus are based of the example found at this location http://blog.skeltonnetworks.com/2010/03/python-curses-custom-menuData/
The rest of the work was done by Matthew Bennett and he requests you keep these two mentions when you reuse the code :-)
Basic code refactoring by Andrew Scheller"

Another version of this using classes: https://gist.github.com/etkirsch/53505478f53aeeac24a5

Handy guide that pointed me to a lot of tools I used: https://www.jeffknupp.com/blog/2013/08/16/open-sourcing-a-python-project-the-right-way/
