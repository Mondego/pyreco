Items
=====

.. toctree::
   :maxdepth: 4

   cursesmenu/items/CommandItem
   cursesmenu/items/ExitItem
   cursesmenu/items/ExternalItem
   cursesmenu/items/FunctionItem
   cursesmenu/items/MenuItem
   cursesmenu/items/SelectionItem
   cursesmenu/items/SubmenuItem
