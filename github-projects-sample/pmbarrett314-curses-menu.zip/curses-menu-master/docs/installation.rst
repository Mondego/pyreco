Installation
============

Windows users should visit `here <http://www.lfd.uci.edu/~gohlke/pythonlibs/#curses>`_ and download the curses build
appropriate to your machine and version of Python.


Everyone should run::

    pip install curses-menu
