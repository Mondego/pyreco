Functions
=========

.. autofunction:: cursesmenu.clear_terminal
.. autofunction:: cursesmenu.old_curses_menu.parse_old_menu
    :noindex:
