ExitItem
========

Bases: :class:`cursesmenu.items.MenuItem`

.. autoclass:: cursesmenu.items.ExitItem
    :members:
