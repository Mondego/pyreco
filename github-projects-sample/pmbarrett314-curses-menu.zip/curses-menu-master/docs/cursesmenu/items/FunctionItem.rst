FunctionItem
============

Bases: :class:`cursesmenu.items.ExternalItem`

.. autoclass:: cursesmenu.items.FunctionItem
    :members:
