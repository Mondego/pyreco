SubmenuItem
===========

Bases: :class:`cursesmenu.items.MenuItem`

.. autoclass:: cursesmenu.items.SubmenuItem
    :members:
