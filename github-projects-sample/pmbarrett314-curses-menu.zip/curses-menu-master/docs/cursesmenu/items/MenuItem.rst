MenuItem
========

.. autoclass:: cursesmenu.items.MenuItem
    :members:
