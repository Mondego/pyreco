CommandItem
===========

Bases: :class:`cursesmenu.items.ExternalItem`

.. autoclass:: cursesmenu.items.CommandItem
    :members:
