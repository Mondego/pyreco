SelectionItem
=============

Bases: :class:`cursesmenu.items.MenuItem`

.. autoclass:: cursesmenu.items.SelectionItem
    :members:
