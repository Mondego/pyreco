SelectionMenu --- Quickly get a selection
=========================================

Bases: :class:`cursesmenu.CursesMenu`

.. autoclass:: cursesmenu.SelectionMenu
    :members:
