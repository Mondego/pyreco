API Reference
=============
.. toctree::
    :maxdepth: 4

    cursesmenu/CursesMenu
    cursesmenu/SelectionMenu
    items
    cursesmenu/functions
