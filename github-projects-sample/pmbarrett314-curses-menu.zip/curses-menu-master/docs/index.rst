.. curses-menu documentation master file, created by
   sphinx-quickstart on Fri Dec 18 18:18:50 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to curses-menu's documentation!
=======================================

Contents:

.. toctree::
   :maxdepth: 4

   installation
   usage
   cursesmenu


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

