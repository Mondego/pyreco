
class PyxcError(Exception): pass

class NoTransformationForNode(PyxcError): pass
