# THIS PROJECT HAS MOVED

Please join us at https://github.com/python-diamond/Diamond
