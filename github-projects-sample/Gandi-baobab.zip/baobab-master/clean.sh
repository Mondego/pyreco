#!/bin/sh

rm -rf baobab.egg-info build baobab.ng/build node_modules baobab.ng/node_modules
dh_clean
