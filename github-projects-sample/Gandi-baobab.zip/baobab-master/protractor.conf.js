exports.config = {
  seleniumAddress: 'http://localhost:4444/wd/hub',
  specs: ['baobab.front/tests/integration/*.js']
};
