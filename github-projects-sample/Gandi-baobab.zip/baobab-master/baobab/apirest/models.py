# -*- coding: utf-8 -*-
"""
Mandatory to be able to do test
"""
