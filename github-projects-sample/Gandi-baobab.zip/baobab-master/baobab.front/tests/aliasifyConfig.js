module.exports = {
  aliases: {
    "../api": "../tests/mocks/api"
  },
  verbose: true
}
