License
=======

.. include:: ../../../LICENSE.txt