from livestream.models import Stream
from django.contrib import admin

admin.site.register(Stream)
