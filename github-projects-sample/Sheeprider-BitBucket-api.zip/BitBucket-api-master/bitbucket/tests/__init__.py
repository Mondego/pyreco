# -*- coding: utf-8 -*-
from bitbucket.tests.public import *

if __name__ == "__main__":
    unittest.main()
