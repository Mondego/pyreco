reset
./uninstall.sh
./install.sh
python example/manage.py test axes --traceback