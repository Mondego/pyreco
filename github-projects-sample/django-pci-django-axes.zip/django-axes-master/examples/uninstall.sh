pip uninstall django-axes -y
rm build -rf
rm dist -rf
rm django_axes.egg-info -rf
rm django-axes.egg-info -rf