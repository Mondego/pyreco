reset
./uninstall.sh
./install.sh