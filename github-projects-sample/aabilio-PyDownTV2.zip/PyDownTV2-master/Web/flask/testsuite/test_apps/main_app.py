import flask

# Test Flask initialization with main module.
app = flask.Flask('__main__')
