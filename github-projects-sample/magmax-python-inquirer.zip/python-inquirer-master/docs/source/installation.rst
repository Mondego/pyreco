Installation
============

To install it, just execute:

.. code:: bash

   pip install inquirer

Usage example:

.. literalinclude:: ../../examples/mixed.py
